﻿
Public Class SessionHandler
    Public Shared Property PointManager() As gheat.PointManager
        Get
            If HttpContext.Current.Session("PointManager") Is Nothing Then
                'HttpContext.Current.Session("PointManager") = New gheat.PointManager(New WeightingDelegate())
                HttpContext.Current.Session("PointManager") = New gheat.PointManager()
            End If
            Return DirectCast(HttpContext.Current.Session("PointManager"), gheat.PointManager)
        End Get
        Set(ByVal value As gheat.PointManager)
            HttpContext.Current.Session("PointManager") = value
        End Set
    End Property
End Class
