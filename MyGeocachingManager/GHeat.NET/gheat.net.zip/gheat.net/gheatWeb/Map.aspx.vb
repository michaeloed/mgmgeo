﻿Public Partial Class Map
    Inherits System.Web.UI.Page
    Protected googleMapsKey As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim lineSplit() As String
        Dim pm As gheat.PointManager

        'Switch the key based on the server name
        Select Case Request.ServerVariables("SERVER_NAME")
            Case "localhost"
                googleMapsKey = "ABQIAAAA6tmekeDSEFECjxSogk8CSBT2yXp_ZAY8_ufC3CFXhHIE1NvwkxRymIYx2Ki4BDvTjlwQ1_HJNKcojA"
            Case Else
                Throw New Exception("Server not found '" + Request.ServerVariables("SERVER_NAME") + "' So i cant get the google maps api key")
        End Select
        pm = SessionHandler.PointManager

        If pm.PointCount = 0 Then pm.LoadPointsFromFile("points.txt")
        pm.AddPoint(New GMap.NET.PointLatLng(30.123866, -92.070673))
        'For Each line As String In Request("Address").Split("|")
        '    lineSplit = line.Split(",")
        '    pm.AddPoint(New GMap.NET.PointLatLng(lineSplit(0), lineSplit(1)))
        'Next
        If Not Page.IsPostBack Then
            For Each item As String In gheat.GHeat.AvailableColorSchemes()
                colorSchemes.Items.Add(item)
            Next
        End If
    End Sub

End Class