﻿Public Partial Class Tile
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim image As System.Drawing.Bitmap
        Dim stream As New System.IO.MemoryStream()

        Response.Clear()

        Response.ContentType = "image/png"
        image = gheat.GHeat.GetTile(SessionHandler.PointManager, Request("colorScheme"), CInt(Request("zoom")), CInt(Request("x")), CInt(Request("y")))

        'Must save the image to a stream because png's need a stream that can seek back and forth.
        image.Save(DirectCast(stream, System.IO.Stream), System.Drawing.Imaging.ImageFormat.Png)

        stream.WriteTo(Response.OutputStream)

        Response.Flush()
    End Sub

End Class