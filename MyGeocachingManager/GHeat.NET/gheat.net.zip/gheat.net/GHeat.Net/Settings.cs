﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gheat
{
    public class Settings
    {
        public static string BaseDirectory
        {
            get;
            set;
        }
    }
}
