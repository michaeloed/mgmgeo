﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace gheat
{
    /// <summary>
    /// Thrown when no weight handler is set and some function is called requiring a weight handler
    /// </summary>
    public class NoWeightHandler : Exception 
    {
        public NoWeightHandler(String message) : base(message) {}
    }

    /// <summary>
    /// Manages the points to be applied to the tiles
    /// </summary>
    public class PointManager
    {
        List<GMap.NET.PointLatLngH> _pointList;
        private GMap.NET.Projections.MercatorProjection _projection = new GMap.NET.Projections.MercatorProjection();
        IWeightHandler _weightHandler;

        public PointManager():this(null){}

        /// <summary>
        /// Weight handle is used to get the weight for each point
        /// </summary>
        /// <param name="weightHandle"></param>
        public PointManager(IWeightHandler weightHandle)
        {
            _pointList = new List<GMap.NET.PointLatLngH>();
            _weightHandler = weightHandle;
        }

        /// <summary>
        /// Adds the point to the list. Also applies the weight to the point when their is point data
        /// </summary>
        /// <param name="point"></param>
        public void AddPoint(GMap.NET.PointLatLngH point)
        {
            //Apply the weight to the new point
            if (_weightHandler != null && point.Data != null) point.Weight = _weightHandler.Evaluate(point.Data);
            _pointList.Add(point);
        }

        /// <summary>
        /// Adds the points to the list. Also applies the weight to the point when their is point data
        /// </summary>
        /// <param name="points"></param>
        public void AddPoint(GMap.NET.PointLatLngH[] points)
        {
            //Apply the weight to the new point
            if (_weightHandler != null)
                for (int i = 0; i < points.Length;i++ )
                    if (points[i].Data != null) points[i].Weight = _weightHandler.Evaluate(points[i].Data);

            _pointList.AddRange(points) ;
        }

        /// <summary>
        /// Updates all of the weights for each point. Should not be called if their is no weight handlers
        /// </summary>
        public void UpdatePointWeights()
        {
            GMap.NET.PointLatLngH tempPoint;
            if (_weightHandler == null)
                throw new NoWeightHandler("Point weights can't be updated because a weight handler was not specified");
            else
                for (int i = 0; i < _pointList.Count; i++)
                {
                    tempPoint = _pointList[i];
                    if (tempPoint.Data != null) tempPoint.Weight = _weightHandler.Evaluate(tempPoint.Data);
                    _pointList[i] = tempPoint;
                }
        }

        /// <summary>
        /// Gets the count of all of the points
        /// </summary>
        /// <returns></returns>
        public int PointCount()
        {
            return _pointList.Count;
        }

        /// <summary>
        /// Clears all of the points from the list
        /// </summary>
        public void ClearPointList()
        {
            _pointList.Clear(); 
        }

        static private Double doubleParse(String s)
        {
        	return Double.Parse(s.Replace(',', '.'), CultureInfo.InvariantCulture);
        }
        
        /// <summary>
        /// Loads points from a file, just like in the Python GHeat app
        /// </summary>
        /// <param name="source"></param>
        /// <param name="weight">Force a weight on the point for testing</param>
        public void LoadPointsFromFile(string source,decimal weight)
        {
            string[] item;
            string[] lines = System.IO.File.ReadAllLines(source);
            foreach (string line in lines)
            {
                item = line.Split(',');
                _pointList.Add(new GMap.NET.PointLatLngH(doubleParse(item[1]), doubleParse(item[2]),null,weight));
            }
        }

        /// <summary>
        /// Loads points from a file, just like in the Python GHeat app
        /// </summary>
        /// <param name="source"></param>
        public void LoadPointsFromFile(string source)
        {
            string[] item;
            string[] lines = System.IO.File.ReadAllLines(source);
            foreach (string line in lines)
            {
                item = line.Split(',');
                _pointList.Add(new GMap.NET.PointLatLngH(doubleParse(item[1]), doubleParse(item[2])));
            }
        }

        /// <summary>
        /// Gets all of the points in the diameter specified
        /// </summary>
        /// <param name="center"></param>
        /// <param name="pixelsFromCenter">diameter</param>
        /// <param name="zoom">current zoom</param>
        /// <returns></returns>
        public GMap.NET.GPointH[] GetPointsAroundCenter(GMap.NET.PointLatLngH center,int pixelsFromCenter, int zoom)
        {
            GMap.NET.GPointH centerAsPixels;
            GMap.NET.GPointH tlb;
            GMap.NET.GPointH lrb;
            List<GMap.NET.GPointH> points = new List<GMap.NET.GPointH>();
            GMap.NET.GSize max_lrb;
            GMap.NET.GSize min_tlb;
            GMap.NET.GPointH tempPoint;


            centerAsPixels = new GMap.NET.GPointH(_projection.FromLatLngToPixel(center.ToG(),zoom), center.Data, center.Weight);
            min_tlb = _projection.GetTileMatrixMinXY(zoom);
            max_lrb = _projection.GetTileMatrixMaxXY(zoom);

            tlb = new GMap.NET.GPointH(
                             centerAsPixels.X - pixelsFromCenter,
                             centerAsPixels.Y - pixelsFromCenter);
            
            lrb = new GMap.NET.GPointH(
                           centerAsPixels.X + pixelsFromCenter,
                           centerAsPixels.Y + pixelsFromCenter);

            foreach (GMap.NET.PointLatLngH llPoint in GetList(tlb, lrb, zoom, false))
            {
                //Add the point to the list
                tempPoint = new GMap.NET.GPointH(_projection.FromLatLngToPixel(llPoint.Lat, llPoint.Lng, zoom));
                tempPoint.Data = llPoint.Data;
                tempPoint.Weight = llPoint.Weight;
                points.Add(tempPoint);
            }
            return points.ToArray();
        }

        /// <summary>
        /// Gets all of the points that fit on the tile
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="dot"></param>
        /// <param name="zoom"></param>
        /// <param name="newMethod"></param>
        /// <returns></returns>
        public GMap.NET.GPointH[]  GetPointsForTile(int x, int y,System.Drawing.Bitmap dot ,int zoom, bool newMethod)
        {
            List<GMap.NET.GPointH> points = new List<GMap.NET.GPointH>();
            GMap.NET.GSize maxTileSize;
            GMap.NET.GPointH adjustedPoint;
            GMap.NET.GPointH pixelCoordinate;
            GMap.NET.GPointH mapPoint;
            
            maxTileSize = _projection.GetTileMatrixMaxXY(zoom);
            //Top Left Bounds
            GMap.NET.GPointH tlb =new GMap.NET.GPointH(_projection.FromTileXYToPixel(new GMap.NET.GPoint(x, y)));

            maxTileSize = new GMap.NET.GSize(GHeat.SIZE, GHeat.SIZE);
            //Lower right bounds
            GMap.NET.GPointH lrb = new GMap.NET.GPointH((tlb.X + (int)maxTileSize.Width) + dot.Width, (tlb.Y + (int)maxTileSize.Height) + dot.Width);

            //pad the Top left bounds
            tlb = new GMap.NET.GPointH(tlb.X - dot.Width, tlb.Y - dot.Height);

       
            //Go throught the list and convert the points to pixel cooridents
            foreach (GMap.NET.PointLatLngH llPoint in GetList(tlb,lrb,zoom,newMethod))
            {
                //Now go through the list and turn it into pixel points
                pixelCoordinate = new GMap.NET.GPointH(_projection.FromLatLngToPixel(llPoint.Lat, llPoint.Lng, zoom));

                //Make sure the weight and data is still pointing after the conversion
                pixelCoordinate.Data = llPoint.Data;
                pixelCoordinate.Weight = llPoint.Weight;

                mapPoint = new GMap.NET.GPointH(_projection.FromPixelToTileXY(pixelCoordinate.ToG()), pixelCoordinate.Data, pixelCoordinate.Weight);
                mapPoint.Data = pixelCoordinate.Data;

                //Adjust the point to the specific tile
                adjustedPoint = AdjustMapPixelsToTilePixels(new GMap.NET.GPointH(x, y), pixelCoordinate);

                //Make sure the weight and data is still pointing after the conversion
                adjustedPoint.Data = pixelCoordinate.Data;
                adjustedPoint.Weight = pixelCoordinate.Weight;

                //Add the point to the list
                points.Add(adjustedPoint);
            }

            return points.ToArray() ;
        }

        /// <summary>
        /// Gets all of the points in the list (Lat Lng Format)
        /// </summary>
        /// <returns></returns>
        public GMap.NET.PointLatLngH[] GetAllPoints()
        {
            return _pointList.ToArray();
        }

        /// <summary>
        /// Gets a list of points that fit with in the Top Left Bounds and Lower Right Bounds
        /// </summary>
        /// <param name="tlb">Top Left Bounds</param>
        /// <param name="lrb">Lower Right Bounds</param>
        /// <param name="zoom"></param>
        /// <param name="newMethod"></param>
        /// <returns></returns>
        protected GMap.NET.PointLatLngH[] GetList(GMap.NET.GPointH tlb, GMap.NET.GPointH lrb, int zoom, bool newMethod)
        {
            List<GMap.NET.GPointH> points = new List<GMap.NET.GPointH>();
            IEnumerable<GMap.NET.PointLatLngH> llList;

            GMap.NET.PointLatLngH ptlb;
            GMap.NET.PointLatLngH plrb;

            ptlb = new GMap.NET.PointLatLngH(_projection.FromPixelToLatLng(tlb.ToG(), zoom), tlb.Data, tlb.Weight);
            plrb = new GMap.NET.PointLatLngH(_projection.FromPixelToLatLng(lrb.ToG(), zoom), tlb.Data, tlb.Weight);

            //Find all of the points that belong in the expanded tile
            // Some points may appear in more than one tile depending where they appear
            if (newMethod)
            {
                ListSearch ls = new ListSearch(_pointList, ptlb, plrb);
                llList = ls.GetMatchingPoints();
            }
            else
            {
                llList = from point in _pointList
                         where
                                point.Lat <= ptlb.Lat && point.Lng >= ptlb.Lng &&
                                point.Lat >= plrb.Lat && point.Lng <= plrb.Lng
                         select point;
            }
            return llList.ToArray();
        }

        /// <summary>
        /// Converts the whole map pixes to tile pixels
        /// </summary>
        /// <param name="tileXYPoint"></param>
        /// <param name="mapPixelPoint"></param>
        /// <returns></returns>
        public static GMap.NET.GPointH AdjustMapPixelsToTilePixels(GMap.NET.GPointH tileXYPoint, GMap.NET.GPointH mapPixelPoint)
        {
            return new GMap.NET.GPointH(mapPixelPoint.X - (tileXYPoint.X * GHeat.SIZE), mapPixelPoint.Y - (tileXYPoint.Y * GHeat.SIZE));
        }
    }
}
