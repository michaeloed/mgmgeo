﻿
namespace GMap.NET
{
   using System.Globalization;

   /// <summary>
   /// the point of coordinates
   /// </summary>
   public struct PointLatLngH
   {
      public static readonly PointLatLngH Empty;  
      private double lat;
      private double lng;
      private object _data;
      private decimal? _weight;

      public PointLatLngH(PointLatLng p)
      {
         this.lat = p.Lat;
         this.lng = p.Lng;
         this._data = null;
         this._weight = null;
      }
      
      public PointLatLngH(PointLatLng p, object data,decimal? weight)
      {
         this.lat = p.Lat;
         this.lng = p.Lng;
         this._data = data;
          this._weight = weight;
      }
      
      public PointLatLngH(double lat, double lng, object data)
      {
          this.lat = lat;
          this.lng = lng;
          this._data = data;
          this._weight = null;
      }

      public PointLatLngH(double lat, double lng, object data,decimal? weight)
      {
          this.lat = lat;
          this.lng = lng;
          this._data = data;
          this._weight = weight;
      }

      public PointLatLngH(double lat, double lng)
      {
         this.lat = lat;
         this.lng = lng;
         this._data = null;
         this._weight = null;
      }

      public bool IsEmpty
      {
         get
         {
            return ((this.lng == 0d) && (this.lat == 0d));
         }
      }

      public double Lat
      {
         get
         {
            return this.lat;
         }
         set
         {
            this.lat = value;
         }
      }

      public double Lng
      {
         get
         {
            return this.lng;
         }
         set
         {
            this.lng = value;
         }
      }

      /// <summary>
      /// Allows you to assoicate data with the point
      /// </summary>
      public object Data { get { return _data; } set {_data = value ;} }

      public decimal? Weight { get { return _weight; } set { _weight = value; } }

      public static bool operator >(PointLatLngH lhs, PointLatLngH rhs)
      {
          return (lhs.Lat > rhs.Lat && lhs.Lng > rhs.Lng);
      }

      public static bool operator >=(PointLatLngH lhs, PointLatLngH rhs)
      {
          return (lhs.Lat >= rhs.Lat && lhs.Lng >= rhs.Lng);
      }

      public static bool operator <=(PointLatLngH lhs, PointLatLngH rhs)
      {
          return (lhs.Lat <= rhs.Lat && lhs.Lng <= rhs.Lng);
      }

      public static bool operator <(PointLatLngH lhs, PointLatLngH rhs)
      {
          return (lhs.Lat < rhs.Lat && lhs.Lng < rhs.Lng);
      }

      public static PointLatLngH operator+(PointLatLngH pt, SizeLatLng sz)
      {
         return Add(pt, sz);
      }

      public static PointLatLngH operator-(PointLatLngH pt, SizeLatLng sz)
      {
         return Subtract(pt, sz);
      }

      public static bool operator==(PointLatLngH left, PointLatLngH right)
      {
         return ((left.Lng == right.Lng) && (left.Lat == right.Lat));
      }

      public static bool operator!=(PointLatLngH left, PointLatLngH right)
      {
         return !(left == right);
      }

      public static PointLatLngH Add(PointLatLngH pt, SizeLatLng sz)
      {
         return new PointLatLngH(pt.Lat - sz.HeightLat, pt.Lng + sz.WidthLng);
      }

      public static PointLatLngH Subtract(PointLatLngH pt, SizeLatLng sz)
      {
         return new PointLatLngH(pt.Lat + sz.HeightLat, pt.Lng - sz.WidthLng);
      }

      public override bool Equals(object obj)
      {
         if(!(obj is PointLatLngH))
         {
            return false;
         }
         PointLatLngH tf = (PointLatLngH) obj;
         return (((tf.Lng == this.Lng) && (tf.Lat == this.Lat)) && tf.GetType().Equals(base.GetType()));
      }

      public void Offset(PointLatLngH pos)
      {
         this.Offset(pos.Lat, pos.Lng);
      }

      public void Offset(double lat, double lng)
      {
         this.Lng += lng;
         this.Lat -= lat;
      }

      public override int GetHashCode()
      {
         return base.GetHashCode();
      }

      public PointLatLng ToG()
      {
      	return new PointLatLng(this.lat, this.lng);
      }
      
      public override string ToString()
      {
         return string.Format(CultureInfo.CurrentCulture, "{{Lat={0}, Lng={1}}}", this.Lat, this.Lng);
      }

      static PointLatLngH()
      {
         Empty = new PointLatLngH();
      }
   }
}