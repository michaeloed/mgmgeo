﻿Public Class TileTest

    Private Sub TileTest_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim tile As System.Drawing.Bitmap = gheat.Tile.GetBlankImage(256, 256)
        Dim dot As System.Drawing.Bitmap
        Dim colorScheme As System.Drawing.Bitmap
        Dim zoom As Integer = 20
        Dim output As System.Drawing.Bitmap
        Dim points() As GMap.NET.GPointH

        colorScheme = New System.Drawing.Bitmap("__\etc\color-schemes\classic.png")
        dot = New System.Drawing.Bitmap("__\etc\dots\dot" + zoom.ToString() + ".png")
        points = New GMap.NET.GPointH() {New GMap.NET.GPointH(100, 100, Nothing, 0.5)}

        'output = gheat.Tile.Generate(colorScheme, dot, zoom, 1, 1, points)

        output = gheat.Tile.AddPoints(tile, dot, points)

        PictureBox1.Image = output
        output.Save("tile.png")

    End Sub
End Class