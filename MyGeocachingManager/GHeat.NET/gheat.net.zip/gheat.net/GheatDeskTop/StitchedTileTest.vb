﻿Public Class StitchedTileTest

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim pm As New gheat.PointManager()
        Dim g As Graphics
        Dim tempImage As System.Drawing.Bitmap
        Dim zoom As Integer = 4
        Dim startX As Integer = 2
        Dim startY As Integer = 5
        Dim maxX As Integer = startX + 10
        Dim maxY As Integer = startY + 10
        Dim canvasImage As New System.Drawing.Bitmap(maxX * 256 - (startX * 256), maxY * 256 - (startY * 256), System.Drawing.Imaging.PixelFormat.Format32bppArgb)

        gheat.Settings.BaseDirectory = "..\..\..\gheatWeb\__\etc\"

        g = Graphics.FromImage(canvasImage)

        pm.LoadPointsFromFile("..\..\..\points.txt")

        For x As Integer = startX To maxX
            For y As Integer = startY To maxY
                tempImage = gheat.GHeat.GetTile(pm, "classic", zoom, x, y)
                g.DrawImage(tempImage, New System.Drawing.PointF(x * 256 - (startX * 256), y * 256 - (startY * 256)))
            Next
        Next
        PictureBox1.Image = canvasImage
        canvasImage.Save("toto.png")
    End Sub
End Class