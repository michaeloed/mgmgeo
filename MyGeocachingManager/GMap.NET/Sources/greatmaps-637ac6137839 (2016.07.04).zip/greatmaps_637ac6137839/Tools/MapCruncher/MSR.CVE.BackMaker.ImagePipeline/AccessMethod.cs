using System;
namespace MSR.CVE.BackMaker.ImagePipeline
{
	public enum AccessMethod
	{
		Render,
		FetchBounds,
		ImageDetail,
		RendererCredit
	}
}
