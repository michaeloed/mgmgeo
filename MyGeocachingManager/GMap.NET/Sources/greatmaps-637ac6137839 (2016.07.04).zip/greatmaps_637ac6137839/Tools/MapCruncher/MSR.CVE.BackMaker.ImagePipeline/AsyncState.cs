using System;
namespace MSR.CVE.BackMaker.ImagePipeline
{
	internal enum AsyncState
	{
		Prequeued,
		Queued
	}
}
